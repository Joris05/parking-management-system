Put the project inside the xampp/htdocs or wamp/www

import the database name parking.sql inside the project folder name database

default login

username : admin@gmail.com
password : admin123